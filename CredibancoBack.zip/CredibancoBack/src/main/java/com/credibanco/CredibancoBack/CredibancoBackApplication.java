package com.credibanco.CredibancoBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CredibancoBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CredibancoBackApplication.class, args);
	}

}
